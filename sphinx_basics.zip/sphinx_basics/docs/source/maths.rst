Math Module
===========

Documenting individual functions:

.. automodule:: maths.add
   :members:

.. automodule:: maths.divide
   :members:

.. automodule:: maths.multiply
   :members:

.. automodule:: maths.subtract
   :members:
